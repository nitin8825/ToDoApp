﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ToDoApp.Data;
using ToDoApp.Models;

namespace ToDoApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ToDoController : ControllerBase
    {
        private readonly ToDoDbContext context;
        public ToDoController(ToDoDbContext DbContext) 
        {
            context = DbContext;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<ToDo>>> GetToDos()
        {
            return await context.ToDos.ToListAsync();
        }

        [HttpPost]
        public ActionResult CreateToDo(ToDo todo)
        {
            context.ToDos.Add(todo);
            context.SaveChanges();

            return Ok();
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateTodo(int id, ToDo todo)
        {
            if (id != todo.Id)
            {
                return BadRequest();
            }

            context.Entry(todo).State = EntityState.Modified;

            try
            {
                await context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!context.ToDos.Any(e => e.Id == id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteTodo(int id)
        {
            var todo = await context.ToDos.FindAsync(id);
            if (todo == null)
            {
                return NotFound();
            }

            context.ToDos.Remove(todo);
            await context.SaveChangesAsync();

            return NoContent();
        }
    }
}
    