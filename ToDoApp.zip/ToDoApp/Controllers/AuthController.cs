﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using ToDoApp.Models;

namespace ToDoApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {

        private readonly IConfiguration configuration; 
        public AuthController(IConfiguration _configuration) { 
        
            configuration = _configuration;
        }

        [HttpPost]
        public IActionResult Login([FromBody] LoginModel login)
        {
            if(login.Username == "test" && login.Password == "password")
            {
                var claims = new[]
                {
                    new Claim(ClaimTypes.Name, login.Username),
                };

                var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(configuration["Jwt:SecretKey"]));
                var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
               
                var token = new JwtSecurityToken(
                   issuer: configuration["Jwt:Issuer"],
                   audience: configuration["Jwt:Audience"],
                   claims: claims,
                   expires: DateTime.Now.AddDays(1),
                   signingCredentials: creds
               );

                return Ok(new
                {
                    token = new JwtSecurityTokenHandler().WriteToken(token)
                });

            }
            return Unauthorized();

        }
    }
}
