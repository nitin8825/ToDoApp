import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

export interface Todo {
  id: number;
  title: string;
  isComplete: boolean;
}

@Injectable({
  providedIn: 'root'
})
export class TodoService {

  private apiUrl = "https://localhost:7179/api/ToDo"

  constructor(private http:HttpClient) { }

  getTodos():Observable<any>{
    return this.http.get(this.apiUrl);
  }

  createTodo(todo:any):Observable<any>{
    return this.http.post(this.apiUrl,todo);
  }
}
