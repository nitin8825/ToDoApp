import { CanActivateFn } from '@angular/router';
import { inject } from '@angular/core';

import { Router } from '@angular/router';
import { AuthService } from './services/auth.service';

export const authGuard: CanActivateFn = (route, state) => {
  const authService = inject(AuthService);  // Inject AuthService to check authentication
  const router = inject(Router);  // Inject Router to redirect unauthenticated users

  // Check if the user is authenticated (for example, check if a token exists)
  if (authService.isAuthenticated()) {
    return true;  // Allow access to the route
  } else {
    // If not authenticated, redirect to the login page
    router.navigate(['/login']);
    return false;  // Block access to the route
  }
};