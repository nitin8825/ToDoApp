import { Component } from '@angular/core';
import { AuthService } from '../../services/auth.service';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule,CommonModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  username: string = '';
  password: string = '';
  errorMessage: string = '';

  constructor(private authService:AuthService, private router:Router){}

  login(): void {
    this.authService.login(this.username, this.password).subscribe({
      next: (response) => {
        const token = response.token;  // Get the token from the response
        console.log(token);
        this.authService.saveToken(token);  // Save token to localStorage
        this.router.navigate(['/dashboard']);  // Navigate to a protected route after login
      },
      error: (err) => {
        this.errorMessage = 'Invalid username or password';  // Show error if login fails
      }
    });
  }
}
