import { Component, OnInit, Output,EventEmitter } from '@angular/core';
import { TodoService } from '../../services/todo.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';


@Component({
  selector: 'app-todo-form',
  standalone: true,
  imports: [CommonModule,FormsModule],
  templateUrl: './todo-form.component.html',
  styleUrl: './todo-form.component.css'
})
export class TodoFormComponent implements OnInit {
  title:string = "";

  @Output() newTodo = new EventEmitter<any>();
  constructor(private todoservice:TodoService){

  }

  ngOnInit(){
    console.log(this.title);
  }

  
  addTodo(){
    if (this.title.trim()) {
      this.todoservice.createTodo({title:this.title,isComplete:false}).subscribe(() =>{
        console.log("task submitted");
        this.newTodo.emit({title:this.title,isComplete:false});
        this.title = "";
      });
    }
  }
}
