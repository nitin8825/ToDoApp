import { Component, OnInit } from '@angular/core';
import { TodoService } from '../../services/todo.service';
import { response } from 'express';
import { CommonModule } from '@angular/common';
import { TodoFormComponent } from '../todo-form/todo-form.component';


@Component({
  selector: 'app-todo-list',
  standalone: true,
  imports: [CommonModule,TodoFormComponent],
  templateUrl: './todo-list.component.html',
  styleUrl: './todo-list.component.css'
})


export class TodoListComponent implements OnInit {
  todos:any;

  

  constructor(private todoListService:TodoService){}

ngOnInit(): void {
  this.loadTodos();
}
dataReceived(data:any){
  console.log(data);
}

loadTodos(){
  this.todoListService.getTodos().subscribe(response =>{
    this.todos = response;
    console.log(response);
  });
}



}


